# Titanic-Kaggle-Competition
My analysis for the 'Titanic: Machine Learning from Disaster' competition, hosted by Kaggle.com

This was the first competition that I entered on Kaggle.com, and I am pleased to say that my submission scored in the top 9%.

Files:
Titanic_Analysis.html - an html file of my analysis.
Titanic_Analysis.py - a python file of my analysis.
test.csv - the test data that was provided by Kaggle.com.
train.csv - the train data that was provided by Kaggle.com.
